IF NOT EXISTS (SELECT 1 FROM t_meta_topclass WHERE FTOPCLASSID='5bbf06075934e8')
BEGIN
/****** Object:Data       Script Date: 2019-04-24 10:03:32 ******/
DELETE t_meta_topclass WHERE FTOPCLASSID='5bbf06075934e8' 
INSERT INTO t_meta_topclass(FTOPCLASSID,FSEQ,FVISIBLE,FISDEFAULT) VALUES ('5bbf06075934e8',0,0,0)  

/****** Object:Data       Script Date: 2019-04-24 10:03:32 ******/
DELETE t_meta_topclass_L WHERE FTOPCLASSID='5bbf06075934e8' 
INSERT INTO t_meta_topclass_L(FPKID,FTOPCLASSID,FLOCALEID,FNAME,FTOOLTIPS) VALUES ('5bbf06075934e9','5bbf06075934e8',2052,N'demo201904',N'demo201904')  

END;
IF NOT EXISTS (SELECT 1 FROM t_meta_subsystem WHERE fid='5c874cc9008a1f')
BEGIN
/****** Object:Data       Script Date: 2019-04-24 10:03:32 ******/
DELETE t_meta_subsystem WHERE fid='5c874cc9008a1f' 
INSERT INTO t_meta_subsystem(FID,FTOPCLASSID,FNUMBER,FSEQ,FVISIBLE,FISDEFAULT,FCHECKBOX,FMAPSCCMETAFOLDER,FFUNCPERMISSIONCTRL,FFIELDPERMISSIONCTRL) VALUES ('5c874cc9008a1f','5bbf06075934e8',N'demo',null,null,0,0,N' ','1','1')  

/****** Object:Data       Script Date: 2019-04-24 10:03:32 ******/
DELETE t_meta_subsystem_L WHERE fid='5c874cc9008a1f' 
INSERT INTO t_meta_subsystem_L(FPKID,FID,FLOCALEID,FNAME,FDESCRIPTION) VALUES ('5c874cc9008a20','5c874cc9008a1f',2052,N'demo',N'demo')  

END;
IF NOT EXISTS (SELECT 1 FROM t_meta_consolesubfunc WHERE fsubfuncid='5c87501f008a22')
BEGIN
/****** Object:Data       Script Date: 2019-04-24 10:03:32 ******/
DELETE t_meta_consolesubfunc WHERE fsubfuncid='5c87501f008a22' 
INSERT INTO t_meta_consolesubfunc(FSUBFUNCID,FNUMBER,FSUBSYSTEMID,FSEQ,FISDEFAULT) VALUES ('5c87501f008a22',N'1001',N'5c874cc9008a1f',0,0)  

/****** Object:Data       Script Date: 2019-04-24 10:03:32 ******/
DELETE t_meta_consolesubfunc_L WHERE fsubfuncid='5c87501f008a22' 
INSERT INTO t_meta_consolesubfunc_L(FPKID,FSUBFUNCID,FLOCALEID,FNAME,FDESCRIPTION) VALUES ('5c87501f008a23','5c87501f008a22',2052,N'report',N' ')  

END;
IF NOT EXISTS (SELECT 1 FROM t_meta_consoledetail WHERE fsubfuncid='5c87501f008a22' and fobjectid='kf228f1d8aa9a4b2b8cfcd9171594b469' and ftype='0')
BEGIN
INSERT INTO t_meta_consoledetail
                                                 (FDETAILFUNCID,
                                                  FSUBFUNCID,
                                                  FNUMBER,
                                                  FOBJECTID,
                                                  FTYPE,
                                                  FSTATUS,
                                                  FPERMISSIONITEMID,
                                                  FSEQ,
                                                  FPARAM,
                                                  FCUSTOMPARAMS,
                                                  FTHUMB,
                                                  FLEVEL,
                                                  FVISIBLE,
                                                  FFUNCTIONGROUP,
                                                  FAUTHPMOBJECTTYPEID) 
                                               VALUES 
                                                  ('7f99d396-7ae3-4dca-a552-fcf00313325d','5c87501f008a22',N'SimReportFilter', 'kf228f1d8aa9a4b2b8cfcd9171594b469','0','1' ,' ',0,N'{"FormId":"kf228f1d8aa9a4b2b8cfcd9171594b469","ShowType":"1","formType":"bill"}',N'',null,0,29,13094,' ')
INSERT INTO t_meta_consoledetail_l
                                                       (FPKID,
                                                        FDETAILFUNCID,
                                                        FLOCALEID,
                                                        FNAME) 
                                                      VALUES 
                                                        ('e35caf62-6c5c-43dc-8770-f1b3328a0a8f','7f99d396-7ae3-4dca-a552-fcf00313325d',2052,N'SimReportFilter - 新增')
END;
IF NOT EXISTS (SELECT 1 FROM t_meta_consoledetail WHERE fsubfuncid='5c87501f008a22' and fobjectid='k3942b0b4237c45318e403d3a2d150151' and ftype='0')
BEGIN
INSERT INTO t_meta_consoledetail
                                                 (FDETAILFUNCID,
                                                  FSUBFUNCID,
                                                  FNUMBER,
                                                  FOBJECTID,
                                                  FTYPE,
                                                  FSTATUS,
                                                  FPERMISSIONITEMID,
                                                  FSEQ,
                                                  FPARAM,
                                                  FCUSTOMPARAMS,
                                                  FTHUMB,
                                                  FLEVEL,
                                                  FVISIBLE,
                                                  FFUNCTIONGROUP,
                                                  FAUTHPMOBJECTTYPEID) 
                                               VALUES 
                                                  ('80526e23-0566-42c3-a303-1a6c40d9ade3','5c87501f008a22',N'透视表过滤', 'k3942b0b4237c45318e403d3a2d150151','0','1' ,' ',0,N'{"FormId":"k3942b0b4237c45318e403d3a2d150151","ShowType":"1","formType":"bill"}',N'',null,0,29,13094,' ')
INSERT INTO t_meta_consoledetail_l
                                                       (FPKID,
                                                        FDETAILFUNCID,
                                                        FLOCALEID,
                                                        FNAME) 
                                                      VALUES 
                                                        ('5e3809cf-6db7-4bf1-adce-d42eb4ea5709','80526e23-0566-42c3-a303-1a6c40d9ade3',2052,N'透视表过滤 - 新增')
END;
IF NOT EXISTS (SELECT 1 FROM t_meta_consoledetail WHERE fsubfuncid='5c87501f008a22' and fobjectid='kf65b3565620f4469ad841b7c7b95a105' and ftype='2')
BEGIN
INSERT INTO t_meta_consoledetail
                                                 (FDETAILFUNCID,
                                                  FSUBFUNCID,
                                                  FNUMBER,
                                                  FOBJECTID,
                                                  FTYPE,
                                                  FSTATUS,
                                                  FPERMISSIONITEMID,
                                                  FSEQ,
                                                  FPARAM,
                                                  FCUSTOMPARAMS,
                                                  FTHUMB,
                                                  FLEVEL,
                                                  FVISIBLE,
                                                  FFUNCTIONGROUP,
                                                  FAUTHPMOBJECTTYPEID) 
                                               VALUES 
                                                  ('759dfc1c-ac89-41f4-8241-f736b933bc60','5c87501f008a22',N'SimReport', 'kf65b3565620f4469ad841b7c7b95a105','2','1' ,'6e44119a58cb4a8e86f6c385e14a17ad',0,N'{"FormId":"kf65b3565620f4469ad841b7c7b95a105","ShowType":"1","formType":"sysreport"}',N'',null,0,29,13094,' ')
INSERT INTO t_meta_consoledetail_l
                                                       (FPKID,
                                                        FDETAILFUNCID,
                                                        FLOCALEID,
                                                        FNAME) 
                                                      VALUES 
                                                        ('b40efc84-517b-4f68-b588-0c661404c393','759dfc1c-ac89-41f4-8241-f736b933bc60',2052,N'SimReport - 简单账表')
END;
IF NOT EXISTS (SELECT 1 FROM t_meta_consoledetail WHERE fsubfuncid='5c87501f008a22' and fobjectid='k76dc023a299349148fd3479a2d315d16' and ftype='3')
BEGIN
INSERT INTO t_meta_consoledetail
                                                 (FDETAILFUNCID,
                                                  FSUBFUNCID,
                                                  FNUMBER,
                                                  FOBJECTID,
                                                  FTYPE,
                                                  FSTATUS,
                                                  FPERMISSIONITEMID,
                                                  FSEQ,
                                                  FPARAM,
                                                  FCUSTOMPARAMS,
                                                  FTHUMB,
                                                  FLEVEL,
                                                  FVISIBLE,
                                                  FFUNCTIONGROUP,
                                                  FAUTHPMOBJECTTYPEID) 
                                               VALUES 
                                                  ('df8f5748-dbed-45e5-9341-60d951e84f9c','5c87501f008a22',N'MoveReport', 'k76dc023a299349148fd3479a2d315d16','3','1' ,'6e44119a58cb4a8e86f6c385e14a17ad',0,N'{"FormId":"k76dc023a299349148fd3479a2d315d16","ShowType":"1","formType":"movereport"}',N'',null,0,29,13094,' ')
INSERT INTO t_meta_consoledetail_l
                                                       (FPKID,
                                                        FDETAILFUNCID,
                                                        FLOCALEID,
                                                        FNAME) 
                                                      VALUES 
                                                        ('526c32da-2052-4ce7-830e-76b48c29f72a','df8f5748-dbed-45e5-9341-60d951e84f9c',2052,N'MoveReport - 分页账表')
END;
IF NOT EXISTS (SELECT 1 FROM t_meta_consoledetail WHERE fsubfuncid='5c87501f008a22' and fobjectid='k9746d188e3094c1cb0d0b40b35886587' and ftype='6')
BEGIN
INSERT INTO t_meta_consoledetail
                                                 (FDETAILFUNCID,
                                                  FSUBFUNCID,
                                                  FNUMBER,
                                                  FOBJECTID,
                                                  FTYPE,
                                                  FSTATUS,
                                                  FPERMISSIONITEMID,
                                                  FSEQ,
                                                  FPARAM,
                                                  FCUSTOMPARAMS,
                                                  FTHUMB,
                                                  FLEVEL,
                                                  FVISIBLE,
                                                  FFUNCTIONGROUP,
                                                  FAUTHPMOBJECTTYPEID) 
                                               VALUES 
                                                  ('d0b853d1-bf2d-472b-889b-015abcc24a90','5c87501f008a22',N'SQLReport', 'k9746d188e3094c1cb0d0b40b35886587','6','1' ,' ',0,N'{"FormId":"k9746d188e3094c1cb0d0b40b35886587","ShowType":"1","formType":"sqlreport"}',N'',null,0,29,13094,' ')
INSERT INTO t_meta_consoledetail_l
                                                       (FPKID,
                                                        FDETAILFUNCID,
                                                        FLOCALEID,
                                                        FNAME) 
                                                      VALUES 
                                                        ('b1f06170-bb95-43a1-b955-e5c71686ea8b','d0b853d1-bf2d-472b-889b-015abcc24a90',2052,N'SQLReport - 直接SQL报表')
END;
IF NOT EXISTS (SELECT 1 FROM t_meta_consoledetail WHERE fsubfuncid='5c87501f008a22' and fobjectid='kcb786520232a42c4b62db76f5121dfc1' and ftype='8')
BEGIN
INSERT INTO t_meta_consoledetail
                                                 (FDETAILFUNCID,
                                                  FSUBFUNCID,
                                                  FNUMBER,
                                                  FOBJECTID,
                                                  FTYPE,
                                                  FSTATUS,
                                                  FPERMISSIONITEMID,
                                                  FSEQ,
                                                  FPARAM,
                                                  FCUSTOMPARAMS,
                                                  FTHUMB,
                                                  FLEVEL,
                                                  FVISIBLE,
                                                  FFUNCTIONGROUP,
                                                  FAUTHPMOBJECTTYPEID) 
                                               VALUES 
                                                  ('acd8a724-5395-4b55-abd3-b0d4ed9878cf','5c87501f008a22',N'CrossReport', 'kcb786520232a42c4b62db76f5121dfc1','8','1' ,' ',0,N'{"FormId":"kcb786520232a42c4b62db76f5121dfc1","ShowType":"1"}',N'',null,0,29,13094,' ')
INSERT INTO t_meta_consoledetail_l
                                                       (FPKID,
                                                        FDETAILFUNCID,
                                                        FLOCALEID,
                                                        FNAME) 
                                                      VALUES 
                                                        ('98916e0c-3044-43b8-86f4-52243f8e89f2','acd8a724-5395-4b55-abd3-b0d4ed9878cf',2052,N'CrossReport - 透视表')
END;
