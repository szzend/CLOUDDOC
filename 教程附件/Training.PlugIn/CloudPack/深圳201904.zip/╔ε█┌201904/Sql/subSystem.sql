IF NOT EXISTS (SELECT 1 FROM t_meta_subsystem WHERE fid='5c874cc9008a1f')
BEGIN
/****** Object:Data       Script Date: 2019-04-24 10:03:32 ******/
DELETE t_meta_subsystem WHERE fid='5c874cc9008a1f' 
INSERT INTO t_meta_subsystem(FID,FTOPCLASSID,FNUMBER,FSEQ,FVISIBLE,FISDEFAULT,FCHECKBOX,FMAPSCCMETAFOLDER,FFUNCPERMISSIONCTRL,FFIELDPERMISSIONCTRL) VALUES ('5c874cc9008a1f','5bbf06075934e8',N'demo',null,null,0,0,N' ','1','1')  

/****** Object:Data       Script Date: 2019-04-24 10:03:32 ******/
DELETE t_meta_subsystem_L WHERE fid='5c874cc9008a1f' 
INSERT INTO t_meta_subsystem_L(FPKID,FID,FLOCALEID,FNAME,FDESCRIPTION) VALUES ('5c874cc9008a20','5c874cc9008a1f',2052,N'demo',N'demo')  

END;
